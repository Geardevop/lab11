package com.example.paymentsservice.query;

import com.example.core.PaymentProcessedEvent;
import com.example.paymentsservice.data.PaymentsEntity;
import com.example.paymentsservice.data.PaymentsRepository;
import org.axonframework.eventhandling.EventHandler;
import org.springframework.beans.BeanUtils;

public class PaymentEventHandler {
    private PaymentsRepository paymentsRepository;
    public PaymentEventHandler(PaymentsRepository paymentsRepository){
        this.paymentsRepository = paymentsRepository;
    }
    @EventHandler
    public void on(PaymentProcessedEvent event){
        PaymentsEntity paymentsEntity = new PaymentsEntity();
        BeanUtils.copyProperties(event, paymentsEntity);
        paymentsRepository.save(paymentsEntity);
    }

}
