package com.example.core;

import lombok.Builder;
import lombok.Data;
@Data

public class PaymentProcessedEvent {
    private String paymentId;
    private String orderId;
}

