package com.example.ordersservice.query;

public class OrderQueryHandler {
}
