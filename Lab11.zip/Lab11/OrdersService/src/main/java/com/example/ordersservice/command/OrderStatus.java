package com.example.ordersservice.command;

public enum OrderStatus {
    CREATED, APPROVED, REJECTED
}
