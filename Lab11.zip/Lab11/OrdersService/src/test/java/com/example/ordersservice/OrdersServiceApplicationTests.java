package com.example.ordersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
