package com.example.lab8.query;

public class FindProductsQuery {
}
